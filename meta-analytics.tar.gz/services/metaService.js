const axios = require('axios');
const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

class MetaService {
  constructor() {
    this.baseURL = 'https://graph.facebook.com/v18.0';
    this.accessToken = process.env.META_ACCESS_TOKEN;
    this.appId = process.env.META_APP_ID;
    this.appSecret = process.env.META_APP_SECRET;
    this.adAccountId = process.env.META_AD_ACCOUNT_ID;
    
    // In-memory cache for API responses
    this.cache = new Map();
    this.cacheExpiry = new Map();
    
    // Cache file path for persistence
    this.cacheFile = path.join(__dirname, '..', 'cache', 'meta-cache.json');
    
    // Load cache from file on startup
    this.loadCacheFromFile();
    
    // Save cache on process exit
    process.on('exit', () => {
      this.saveCacheToFile();
    });
    
    process.on('SIGINT', () => {
      this.saveCacheToFile();
      process.exit(0);
    });
    
    process.on('SIGTERM', () => {
      this.saveCacheToFile();
      process.exit(0);
    });
    
    // Cache duration in milliseconds (10 minutes for most data, 2 minutes for today's data)
    this.cacheDurations = {
      account: 10 * 60 * 1000,     // 10 minutes
      ads: 10 * 60 * 1000,         // 10 minutes
      campaigns: 10 * 60 * 1000,   // 10 minutes
      adsets: 10 * 60 * 1000,      // 10 minutes
      todaySpend: 2 * 60 * 1000,   // 2 minutes (more frequent updates)
      campaignInsights: 5 * 60 * 1000, // 5 minutes
      creatives: 30 * 60 * 1000    // 30 minutes (creative data changes less frequently)
    };
    
    if (!this.accessToken) {
      throw new Error('META_ACCESS_TOKEN is required');
    }
    if (!this.adAccountId) {
      throw new Error('META_AD_ACCOUNT_ID is required');
    }
  }

  // Cache helper methods
  getCacheKey(endpoint, params = {}) {
    // Create a unique cache key based on endpoint and params
    const paramString = Object.keys(params).sort().map(key => `${key}=${params[key]}`).join('&');
    return `${endpoint}?${paramString}`;
  }

  getFromCache(cacheKey) {
    const expiry = this.cacheExpiry.get(cacheKey);
    if (expiry && Date.now() < expiry) {
      logger.info(`Cache hit for: ${cacheKey}`);
      return this.cache.get(cacheKey);
    }
    
    // Remove expired cache entry
    if (expiry && Date.now() >= expiry) {
      this.cache.delete(cacheKey);
      this.cacheExpiry.delete(cacheKey);
    }
    
    return null;
  }

  setCache(cacheKey, data, cacheType = 'default') {
    const duration = this.cacheDurations[cacheType] || this.cacheDurations.ads;
    const expiry = Date.now() + duration;
    
    this.cache.set(cacheKey, data);
    this.cacheExpiry.set(cacheKey, expiry);
    
    // Save to file periodically (every 5 cache writes)
    if (this.cache.size % 5 === 0) {
      this.saveCacheToFile();
    }
    
    logger.info(`Cached response for: ${cacheKey} (expires in ${duration/1000}s)`);
  }

  // Load cache from file
  loadCacheFromFile() {
    try {
      if (fs.existsSync(this.cacheFile)) {
        const data = fs.readFileSync(this.cacheFile, 'utf8');
        const cacheData = JSON.parse(data);
        
        // Restore cache and expiry
        this.cache = new Map(Object.entries(cacheData.cache || {}));
        this.cacheExpiry = new Map(Object.entries(cacheData.expiry || {}));
        
        // Clean up expired entries
        this.cleanExpiredCache();
        
        logger.info(`Loaded ${this.cache.size} cache entries from file`);
      }
    } catch (error) {
      logger.warn('Failed to load cache from file:', error.message);
    }
  }

  // Save cache to file
  saveCacheToFile() {
    try {
      // Ensure cache directory exists
      const cacheDir = path.dirname(this.cacheFile);
      if (!fs.existsSync(cacheDir)) {
        fs.mkdirSync(cacheDir, { recursive: true });
      }
      
      const cacheData = {
        cache: Object.fromEntries(this.cache),
        expiry: Object.fromEntries(this.cacheExpiry),
        lastSaved: new Date().toISOString()
      };
      
      fs.writeFileSync(this.cacheFile, JSON.stringify(cacheData, null, 2));
    } catch (error) {
      logger.warn('Failed to save cache to file:', error.message);
    }
  }

  // Clean expired cache entries
  cleanExpiredCache() {
    const now = Date.now();
    for (const [key, expiry] of this.cacheExpiry.entries()) {
      if (expiry <= now) {
        this.cache.delete(key);
        this.cacheExpiry.delete(key);
      }
    }
  }

  // Clear cache (useful for testing or manual refresh)
  clearCache() {
    this.cache.clear();
    this.cacheExpiry.clear();
    
    // Also remove cache file
    try {
      if (fs.existsSync(this.cacheFile)) {
        fs.unlinkSync(this.cacheFile);
      }
    } catch (error) {
      logger.warn('Failed to remove cache file:', error.message);
    }
    
    logger.info('Cache cleared');
  }

  // Get cache stats for monitoring
  getCacheStats() {
    const now = Date.now();
    const activeEntries = Array.from(this.cacheExpiry.entries()).filter(([key, expiry]) => expiry > now);
    
    return {
      totalEntries: this.cache.size,
      activeEntries: activeEntries.length,
      expiredEntries: this.cache.size - activeEntries.length,
      entries: activeEntries.map(([key, expiry]) => ({
        key,
        expiresIn: Math.round((expiry - now) / 1000)
      }))
    };
  }

  // Make authenticated request to Meta Graph API with caching
  async makeRequest(endpoint, params = {}, cacheType = 'default') {
    try {
      // Check cache first
      const cacheKey = this.getCacheKey(endpoint, params);
      const cachedData = this.getFromCache(cacheKey);
      if (cachedData) {
        return cachedData;
      }

      const url = `${this.baseURL}/${endpoint}`;
      const requestParams = {
        access_token: this.accessToken,
        ...params
      };

      logger.info(`Making request to Meta API: ${endpoint}`);
      
      const response = await axios.get(url, {
        params: requestParams,
        timeout: 30000
      });

      // Cache the response
      this.setCache(cacheKey, response.data, cacheType);

      return response.data;
    } catch (error) {
      logger.error(`Meta API request failed for ${endpoint}:`, error.response?.data || error.message);
      throw new Error(`Meta API request failed: ${error.response?.data?.error?.message || error.message}`);
    }
  }

  // Get ad account information
  async getAccountInfo() {
    const endpoint = this.adAccountId;
    const fields = 'id,name,account_status,currency,timezone_name,amount_spent,balance';
    
    return await this.makeRequest(endpoint, { fields }, 'account');
  }

  // Get today's spend data
  async getTodaySpendData() {
    const endpoint = `${this.adAccountId}/insights`;
    
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0]; // YYYY-MM-DD format
    
    // Also get yesterday's data for comparison
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    const requestParams = {
      fields: 'spend,impressions,clicks,cpm,cpc,ctr,frequency,reach,actions',
      time_range: JSON.stringify({
        since: todayStr,
        until: todayStr
      }),
      level: 'account'
    };

    const response = await this.makeRequest(endpoint, requestParams, 'todaySpend');
    
    // Also get yesterday's data for comparison
    const yesterdayParams = {
      fields: 'spend,impressions,clicks,cpm,cpc,ctr,frequency,reach,actions',
      time_range: JSON.stringify({
        since: yesterdayStr,
        until: yesterdayStr
      }),
      level: 'account'
    };
    
    const yesterdayResponse = await this.makeRequest(endpoint, yesterdayParams, 'todaySpend');
    
    // Process today's data
    const todayData = response.data && response.data[0] ? response.data[0] : {};
    const yesterdayData = yesterdayResponse.data && yesterdayResponse.data[0] ? yesterdayResponse.data[0] : {};
    
    // Use the most recent day with data (prefer today, fallback to yesterday if today is empty)
    const primaryData = (todayData.spend && parseFloat(todayData.spend) > 0) ? todayData : yesterdayData;
    const primaryDate = (todayData.spend && parseFloat(todayData.spend) > 0) ? todayStr : yesterdayStr;
    
    // Extract link clicks from actions array
    const getLinkClicks = (data) => {
      if (!data.actions || !Array.isArray(data.actions)) return 0;
      const linkClickAction = data.actions.find(action => action.action_type === 'link_click');
      return linkClickAction ? parseInt(linkClickAction.value || 0) : 0;
    };
    
    const primaryLinkClicks = getLinkClicks(primaryData);
    const yesterdayLinkClicks = getLinkClicks(yesterdayData);
    
    // Calculate link CTR (link clicks / impressions * 100)
    const calculateLinkCTR = (linkClicks, impressions) => {
      if (!impressions || impressions === 0) return 0;
      return (linkClicks / impressions) * 100;
    };
    
    const primaryLinkCTR = calculateLinkCTR(primaryLinkClicks, primaryData.impressions);
    const yesterdayLinkCTR = calculateLinkCTR(yesterdayLinkClicks, yesterdayData.impressions);
    
    // Calculate link CPC (spend / link clicks)
    const calculateLinkCPC = (spend, linkClicks) => {
      if (!linkClicks || linkClicks === 0) return 0;
      return spend / linkClicks;
    };
    
    const primaryLinkCPC = calculateLinkCPC(primaryData.spend, primaryLinkClicks);
    const yesterdayLinkCPC = calculateLinkCPC(yesterdayData.spend, yesterdayLinkClicks);
    
    return {
      // Primary data (most recent with activity)
      spend: parseFloat((parseFloat(primaryData.spend || 0)).toFixed(2)), // Account insights spend is already in dollars
      impressions: parseInt(primaryData.impressions || 0),
      clicks: primaryLinkClicks, // Link clicks instead of total clicks
      total_clicks: parseInt(primaryData.clicks || 0), // Keep total clicks for reference
      cpm: parseFloat(primaryData.cpm || 0), // CPM is already in correct format from Insights API
      cpc: parseFloat(primaryLinkCPC.toFixed(4)), // Link CPC instead of total CPC
      total_cpc: parseFloat(primaryData.cpc || 0), // Keep total CPC for reference
      ctr: parseFloat(primaryLinkCTR.toFixed(4)), // Link CTR instead of total CTR
      total_ctr: parseFloat(primaryData.ctr || 0), // Keep total CTR for reference
      frequency: parseFloat(primaryData.frequency || 0),
      reach: parseInt(primaryData.reach || 0),
      actions: primaryData.actions || [],
      date: primaryDate,
      
      // Yesterday's data for comparison
      yesterday: {
        spend: parseFloat((parseFloat(yesterdayData.spend || 0)).toFixed(2)),
        impressions: parseInt(yesterdayData.impressions || 0),
        clicks: yesterdayLinkClicks, // Link clicks instead of total clicks
        total_clicks: parseInt(yesterdayData.clicks || 0), // Keep total clicks for reference
        cpm: parseFloat(yesterdayData.cpm || 0),
        cpc: parseFloat(yesterdayLinkCPC.toFixed(4)), // Link CPC instead of total CPC
        total_cpc: parseFloat(yesterdayData.cpc || 0), // Keep total CPC for reference
        ctr: parseFloat(yesterdayLinkCTR.toFixed(4)), // Link CTR instead of total CTR
        total_ctr: parseFloat(yesterdayData.ctr || 0), // Keep total CTR for reference
        frequency: parseFloat(yesterdayData.frequency || 0),
        reach: parseInt(yesterdayData.reach || 0),
        actions: yesterdayData.actions || [],
        date: yesterdayStr
      }
    };
  }


  // Get campaign-level insights to match Facebook Ads Manager view
  async getCampaignInsights({ dateRange = '1d', limit = 50 }) {
    const endpoint = `${this.adAccountId}/campaigns`;
    
    const requestParams = {
      fields: 'id,name,status,effective_status,insights{spend,impressions,clicks,cpm,cpc,ctr,frequency,reach,actions,cost_per_action_type}',
      limit,
      time_range: JSON.stringify(this.getDateRange(dateRange))
    };

    const response = await this.makeRequest(endpoint, requestParams, 'campaignInsights');
    
    // Process campaign data with insights
    const campaigns = response.data || [];
    
    return campaigns.map(campaign => {
      const insights = campaign.insights?.data?.[0] || {};
      
      return {
        id: campaign.id,
        name: campaign.name,
        status: campaign.status,
        effective_status: campaign.effective_status,
        spend: parseFloat((parseFloat(insights.spend || 0) / 100).toFixed(2)), // Campaign insights spend is in cents
        impressions: parseInt(insights.impressions || 0),
        clicks: parseInt(insights.clicks || 0),
        cpm: parseFloat(insights.cpm || 0), // Campaign insights CPM is already in dollars
        cpc: parseFloat(insights.cpc || 0), // Campaign insights CPC is already in dollars
        ctr: parseFloat(insights.ctr || 0),
        frequency: parseFloat(insights.frequency || 0),
        reach: parseInt(insights.reach || 0),
        actions: insights.actions || [],
        cost_per_action_type: insights.cost_per_action_type || []
      };
    });
  }

  // Get ads data with insights (Single API request with comprehensive fields)
  async getAdsData({ dateRange = '30d', limit = 50, status, fields }) {
    const endpoint = `${this.adAccountId}/ads`;
    
    const defaultFields = [
      'id',
      'name', 
      'status',
      'effective_status',
      'created_time',
      'updated_time',
      'creative{id,thumbnail_url,image_url,object_story_spec{link_data{image_hash},photo_data{image_hash}},body,title,object_type,image_hash,effective_object_story_id}',
      'insights{impressions,clicks,spend,cpm,cpc,ctr,frequency,reach,actions,cost_per_action_type,date_start,date_stop}'
    ];

    const requestParams = {
      fields: fields || defaultFields.join(','),
      limit,
      time_range: JSON.stringify({
        since: this.getDateRange(dateRange).since,
        until: this.getDateRange(dateRange).until
      })
    };

    // Add status filter if provided
    if (status) {
      requestParams.effective_status = JSON.stringify([status]);
    }

    const response = await this.makeRequest(endpoint, requestParams, 'ads');
    
    // Process and enrich the data
    return this.processAdsData(response.data || []);
  }


  // Get campaigns data
  async getCampaignsData({ dateRange = '30d', limit = 50, status = 'ACTIVE' }) {
    const endpoint = `${this.adAccountId}/campaigns`;
    
    const fields = [
      'id',
      'name',
      'status',
      'effective_status', 
      'created_time',
      'updated_time',
      'insights{impressions,clicks,spend,cpm,cpc,ctr,frequency,reach,actions,cost_per_action_type}'
    ];

    const requestParams = {
      fields: fields.join(','),
      limit,
      effective_status: status,
      time_range: JSON.stringify({
        since: this.getDateRange(dateRange).since,
        until: this.getDateRange(dateRange).until
      })
    };

    const response = await this.makeRequest(endpoint, requestParams, 'campaigns');
    
    return response.data || [];
  }

  // Get ad sets data
  async getAdsetsData({ dateRange = '30d', limit = 50, status = 'ACTIVE' }) {
    const endpoint = `${this.adAccountId}/adsets`;
    
    const fields = [
      'id',
      'name',
      'status',
      'effective_status',
      'created_time', 
      'updated_time',
      'targeting',
      'optimization_goal',
      'billing_event',
      'bid_strategy',
      'insights{impressions,clicks,spend,cpm,cpc,ctr,frequency,reach,actions,cost_per_action_type}'
    ];

    const requestParams = {
      fields: fields.join(','),
      limit,
      effective_status: status,
      time_range: JSON.stringify({
        since: this.getDateRange(dateRange).since,
        until: this.getDateRange(dateRange).until
      })
    };

    const response = await this.makeRequest(endpoint, requestParams, 'adsets');
    
    return response.data || [];
  }

  // Process and enrich ads data
  processAdsData(ads) {
    return ads.map(ad => {
      const insights = ad.insights?.data?.[0] || {};
      
      // Extract and normalize image URL from creative data
      let imageUrl = null;
      let imageSource = 'none';
      
      if (ad.creative) {
        // Determine ad type for appropriate image sizing
        const isVideoAd = ad.creative.object_story_spec?.video_data != null;
        const adType = isVideoAd ? 'video' : 'static';
        
        // Prioritize high-quality images from object_story_spec first
        if (ad.creative.object_story_spec) {
          const spec = ad.creative.object_story_spec;
          
          // Check for video data (for video ads) - this usually has the best quality
          if (spec.video_data && spec.video_data.image_url) {
            imageUrl = this.getHighQualityImageUrl(spec.video_data.image_url, 'video', spec.video_data.image_hash);
            imageSource = 'video_thumbnail';
          }
          
          // Check for photo data
          if (!imageUrl && spec.photo_data && spec.photo_data.url) {
            imageUrl = this.getHighQualityImageUrl(spec.photo_data.url, 'static');
            imageSource = 'photo_data';
          }
          
          // Check for link data (for link ads with images)
          if (!imageUrl && spec.link_data && spec.link_data.picture) {
            imageUrl = this.getHighQualityImageUrl(spec.link_data.picture, 'static');
            imageSource = 'link_data';
          }
        }
        
        // Fall back to direct image fields
        if (!imageUrl) {
          // For static ads, prioritize image_url over thumbnail_url as it often has better quality
          if (ad.creative.image_url) {
            imageUrl = this.getHighQualityImageUrl(ad.creative.image_url, adType, ad.creative.image_hash);
            imageSource = 'image_url';
          } else if (ad.creative.thumbnail_url) {
            imageUrl = this.getHighQualityImageUrl(ad.creative.thumbnail_url, adType, ad.creative.image_hash);
            imageSource = 'thumbnail_url';
          }
        }
      }
      
      return {
        ...ad,
        creative: ad.creative ? {
          ...ad.creative,
          image_url: imageUrl,
          thumbnail_url: imageUrl,
          image_source: imageSource // Track where the image came from
        } : null,
        metrics: {
          impressions: parseInt(insights.impressions || 0),
          clicks: parseInt(insights.clicks || 0),
          spend: parseFloat(insights.spend || 0),
          cpm: parseFloat(insights.cpm || 0),
          cpc: parseFloat(insights.cpc || 0),
          ctr: parseFloat(insights.ctr || 0),
          frequency: parseFloat(insights.frequency || 0),
          reach: parseInt(insights.reach || 0),
          actions: insights.actions || [],
          cost_per_action_type: insights.cost_per_action_type || []
        },
        performance_score: this.calculatePerformanceScore(insights),
        status_color: this.getStatusColor(ad.effective_status)
      };
    });
  }

  // Get creative details including images
  async getCreativeDetails(creativeId) {
    const endpoint = creativeId;
    const fields = 'id,thumbnail_url,image_url,object_story_spec,body,title,object_type';
    
    try {
      const creativeData = await this.makeRequest(endpoint, { fields });
      
      // Extract image URL from various possible locations
      let imageUrl = null;
      
      // Try direct image fields first
      if (creativeData.thumbnail_url) {
        imageUrl = creativeData.thumbnail_url;
      } else if (creativeData.image_url) {
        imageUrl = creativeData.image_url;
      }
      
      // Try to extract from object_story_spec
      if (!imageUrl && creativeData.object_story_spec) {
        const spec = creativeData.object_story_spec;
        
        // Check for photo data
        if (spec.photo_data && spec.photo_data.url) {
          imageUrl = spec.photo_data.url;
        } else if (spec.photo_data && spec.photo_data.image_hash) {
          // Try to get image URL from image hash
          imageUrl = await this.getImageUrlFromHash(spec.photo_data.image_hash);
        }
        
        // Check for link data (for link ads with images)
        if (!imageUrl && spec.link_data && spec.link_data.picture) {
          imageUrl = spec.link_data.picture;
        }
        
        // Check for video data (for video ads)
        if (!imageUrl && spec.video_data && spec.video_data.image_url) {
          imageUrl = spec.video_data.image_url;
        }
      }
      
      return {
        ...creativeData,
        image_url: imageUrl,
        thumbnail_url: imageUrl // Use same URL for both
      };
    } catch (error) {
      logger.error(`Failed to fetch creative details for ${creativeId}:`, error.message);
      return null;
    }
  }

  // Get image URL from image hash
  async getImageUrlFromHash(imageHash) {
    try {
      const endpoint = `${this.adAccountId}/adimages`;
      const params = {
        fields: 'permalink_url',
        hashes: JSON.stringify([imageHash])
      };
      
      const response = await this.makeRequest(endpoint, params);
      
      if (response.data && response.data.length > 0) {
        return response.data[0].permalink_url;
      }
      
      return null;
    } catch (error) {
      logger.warn(`Failed to get image URL for hash ${imageHash}:`, error.message);
      return null;
    }
  }

  // Get high quality image URL - prioritize best available source
  getHighQualityImageUrl(originalUrl, adType = 'static', imageHash = null) {
    if (!originalUrl) return null;
    
    // For now, return the original URL as-is
    // The Image Hash API (/adimages) is only for tech providers accessing client data
    // For your own ad account, we use the /ads endpoint with creative fields
    
    return originalUrl;
  }

  // Optimize image URL parameters for better quality
  optimizeImageUrl(url) {
    if (!url || !url.includes('scontent')) return url;
    
    try {
      // Remove low-quality parameters and add high-quality ones
      let optimizedUrl = url
        .replace(/p64x64[^&]*/g, '') // Remove p64x64 parameter
        .replace(/q75[^&]*/g, '') // Remove q75 parameter
        .replace(/tt6[^&]*/g, '') // Remove tt6 parameter
        .replace(/&+/g, '&') // Clean up multiple ampersands
        .replace(/[?&]$/, ''); // Remove trailing ? or &
      
      // Add high-quality parameters
      if (optimizedUrl.includes('?')) {
        optimizedUrl += '&w=1080&h=1080&q=100';
      } else {
        optimizedUrl += '?w=1080&h=1080&q=100';
      }
      
      return optimizedUrl;
    } catch (error) {
      logger.warn(`Error optimizing URL:`, error.message);
      return url;
    }
  }


  // Calculate a performance score based on key metrics
  calculatePerformanceScore(insights) {
    const spend = parseFloat(insights.spend || 0);
    const impressions = parseInt(insights.impressions || 0);
    const clicks = parseInt(insights.clicks || 0);
    const ctr = parseFloat(insights.ctr || 0);
    
    if (spend === 0 || impressions === 0) return 0;
    
    // Simple scoring algorithm - can be enhanced
    let score = 0;
    
    // CTR score (0-40 points)
    if (ctr > 0.02) score += 40;
    else if (ctr > 0.01) score += 30;
    else if (ctr > 0.005) score += 20;
    else if (ctr > 0.001) score += 10;
    
    // Click volume score (0-30 points)
    if (clicks > 1000) score += 30;
    else if (clicks > 500) score += 20;
    else if (clicks > 100) score += 15;
    else if (clicks > 50) score += 10;
    else if (clicks > 10) score += 5;
    
    // Efficiency score (0-30 points) - based on CPM
    const cpm = parseFloat(insights.cpm || 0);
    if (cpm > 0 && cpm < 5) score += 30;
    else if (cpm < 10) score += 20;
    else if (cpm < 20) score += 10;
    else if (cpm < 50) score += 5;
    
    return Math.min(score, 100);
  }

  // Get status color for UI
  getStatusColor(status) {
    const statusColors = {
      'ACTIVE': '#22c55e',
      'PAUSED': '#f59e0b', 
      'DELETED': '#ef4444',
      'PENDING_REVIEW': '#3b82f6',
      'DISAPPROVED': '#ef4444',
      'PREAPPROVED': '#10b981',
      'PENDING_BILLING_INFO': '#f59e0b',
      'CAMPAIGN_PAUSED': '#6b7280',
      'ADGROUP_PAUSED': '#6b7280'
    };
    
    return statusColors[status] || '#6b7280';
  }

  // Get date range for API requests
  getDateRange(range) {
    const now = new Date();
    const until = now.toISOString().split('T')[0];
    
    let since;
    switch (range) {
      case '7d':
        since = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        break;
      case '30d':
        since = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        break;
      case '90d':
        since = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        break;
      default:
        since = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    }
    
    return { since, until };
  }
}

module.exports = new MetaService();
