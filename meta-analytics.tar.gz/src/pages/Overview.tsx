import { useState, useEffect } from 'react';
import { FiEye, FiMousePointer, FiDollarSign, FiTrendingUp, FiTarget, FiActivity, FiRefreshCw } from 'react-icons/fi';
import type { AdData, AccountInfo, ApiResponse } from '../types';

export function Overview() {
  const [accountInfo, setAccountInfo] = useState<AccountInfo | null>(null);
  const [adsSummary, setAdsSummary] = useState({
    totalAds: 0,
    totalSpend: 0,
    totalImpressions: 0,
    totalClicks: 0,
    averageCTR: 0,
    averageCPM: 0
  });
  const [todaySpend, setTodaySpend] = useState({
    spend: 0,
    impressions: 0,
    clicks: 0,
    cpm: 0,
    cpc: 0,
    ctr: 0,
    date: ''
  });
  const [liveAds, setLiveAds] = useState<AdData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOverviewData = async () => {
    try {
      setLoading(true);
      
      // Fetch data with individual error handling for rate limiting
      const responses = await Promise.allSettled([
        fetch('/api/meta/account'),
        fetch('/api/meta/ads?limit=50'),
        fetch('/api/meta/today-spend'),
        fetch('/api/meta/ads?status=ACTIVE&limit=200')
      ]);

      const [accountResponse, adsResponse, todaySpendResponse, liveAdsResponse] = responses;

      // Handle account info
      if (accountResponse.status === 'fulfilled' && accountResponse.value.ok) {
        const accountResult: ApiResponse<AccountInfo> = await accountResponse.value.json();
        if (accountResult.success) {
          setAccountInfo(accountResult.data);
        }
      }

      // Handle ads data
      if (adsResponse.status === 'fulfilled' && adsResponse.value.ok) {
        const adsResult: ApiResponse<AdData[]> = await adsResponse.value.json();
        if (adsResult.success) {
          const ads = adsResult.data;
          const totalSpend = ads.reduce((sum, ad) => sum + ad.metrics.spend, 0);
          const totalImpressions = ads.reduce((sum, ad) => sum + ad.metrics.impressions, 0);
          const totalClicks = ads.reduce((sum, ad) => sum + ad.metrics.clicks, 0);
          const totalCTR = ads.reduce((sum, ad) => sum + ad.metrics.ctr, 0);
          const totalCPM = ads.reduce((sum, ad) => sum + ad.metrics.cpm, 0);

          setAdsSummary({
            totalAds: ads.length,
            totalSpend,
            totalImpressions,
            totalClicks,
            averageCTR: ads.length > 0 ? totalCTR / ads.length : 0,
            averageCPM: ads.length > 0 ? totalCPM / ads.length : 0
          });
        }
      }

      // Handle today's spend data (this usually has cached data)
      if (todaySpendResponse.status === 'fulfilled' && todaySpendResponse.value.ok) {
        const todaySpendResult: ApiResponse<any> = await todaySpendResponse.value.json();
        if (todaySpendResult.success) {
          setTodaySpend(todaySpendResult.data);
        }
      }

      // Handle live ads
      if (liveAdsResponse.status === 'fulfilled' && liveAdsResponse.value.ok) {
        const liveAdsResult: ApiResponse<AdData[]> = await liveAdsResponse.value.json();
        if (liveAdsResult.success) {
          const liveAds = liveAdsResult.data.filter(ad => ad.effective_status === 'ACTIVE');
          setLiveAds(liveAds);
        }
      }

      // Check if we got any data
      const hasAnyData = accountResponse.status === 'fulfilled' || 
                        adsResponse.status === 'fulfilled' || 
                        todaySpendResponse.status === 'fulfilled' || 
                        liveAdsResponse.status === 'fulfilled';

      if (!hasAnyData) {
        setError('Meta API is currently rate-limited. Please wait a few minutes and refresh the page.');
      } else {
        setError(null);
      }
    } catch (err) {
      console.error('Error fetching overview data:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch overview data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOverviewData();
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  const getPerformanceColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getPerformanceLabel = (score: number) => {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    return 'Needs Attention';
  };

  if (loading) {
    return (
      <div className="min-h-screen relative flex items-center justify-center">
        <div className="fixed inset-0 opacity-40">
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900/30 via-blue-900/30 to-indigo-900/30"></div>
        </div>
        <div className="text-center relative z-10 flex flex-col items-center">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-white/10 rounded-full animate-spin border-t-blue-500"></div>
            <div className="absolute inset-0 w-16 h-16 border-4 border-transparent rounded-full animate-pulse border-t-purple-500"></div>
          </div>
          <p className="mt-6 text-white/80 font-medium text-lg text-center">Loading overview...</p>
          <p className="mt-2 text-white/50 text-sm text-center">Fetching account and ads data</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen relative flex items-center justify-center p-6">
        <div className="fixed inset-0 opacity-40">
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900/30 via-blue-900/30 to-indigo-900/30"></div>
        </div>
        <div className="relative z-10 bg-red-500/10 backdrop-blur-sm border border-red-500/30 rounded-2xl p-8 max-w-md w-full">
          <div className="text-center">
            <div className="text-6xl mb-4">⚠️</div>
            <h2 className="text-2xl font-bold text-white mb-4">Failed to Load Overview</h2>
            <p className="text-white/70 mb-6">{error}</p>
            <button
              onClick={fetchOverviewData}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative">
      {/* Meta Very Dark Blue Background Pattern */}
      <div className="fixed inset-0 opacity-40 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/30 via-blue-900/30 to-indigo-900/30"></div>
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25% 25%, rgba(10, 26, 58, 0.25) 0%, transparent 50%),
                           radial-gradient(circle at 75% 75%, rgba(26, 35, 126, 0.25) 0%, transparent 50%)`
        }}></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-12">
          {/* Header */}
          <div className="animate-fade-in-up mb-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center glass-card">
                  <FiActivity className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">Overview</h1>
                  <p className="text-white/60">Meta Ads account performance summary</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                {todaySpend.spend > 0 && (
                  <div className="flex items-center gap-2 px-3 py-1 bg-green-500/10 border border-green-500/30 rounded-full">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-xs text-green-400 font-medium">Live Data</span>
                  </div>
                )}
                <button
                  onClick={fetchOverviewData}
                  disabled={loading}
                  className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors disabled:opacity-50"
                  title="Refresh data"
                >
                  <FiRefreshCw className={`w-4 h-4 text-white ${loading ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>
          </div>

          {/* Account Info */}
          {accountInfo && (
            <div className="animate-fade-in-up mb-8" style={{ animationDelay: '0.1s' }}>
              <div className="glass-card p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                    <FiTarget className="w-3 h-3 text-white" />
                  </div>
                  <h2 className="text-lg font-bold text-white">Account Information</h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <p className="text-sm text-white/60 mb-1">Account Name</p>
                    <p className="text-lg font-semibold text-white">{accountInfo.name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-white/60 mb-1">Currency</p>
                    <p className="text-lg font-semibold text-white">{accountInfo.currency}</p>
                  </div>
                  <div>
                    <p className="text-sm text-white/60 mb-1">Timezone</p>
                    <p className="text-lg font-semibold text-white">{accountInfo.timezone_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-white/60 mb-1">Lifetime Spend</p>
                    <p className="text-lg font-semibold text-white">{formatCurrency(parseFloat(accountInfo.amount_spent))}</p>
                  </div>
                  <div>
                    <p className="text-sm text-white/60 mb-1">Account Balance</p>
                    <p className="text-lg font-semibold text-white">{formatCurrency(parseFloat(accountInfo.balance))}</p>
                  </div>
                  <div>
                    <p className="text-sm text-white/60 mb-1">Status</p>
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${
                        accountInfo.account_status === 1 ? 'bg-green-400' : 'bg-red-400'
                      }`}></div>
                      <p className="text-lg font-semibold text-white">
                        {accountInfo.account_status === 1 ? 'Active' : 'Inactive'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Performance Summary */}
          <div className="animate-fade-in-up mb-8" style={{ animationDelay: '0.2s' }}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-white/60">Today's Spend</p>
                      <div className="flex items-center gap-1 px-2 py-1 bg-green-500/10 border border-green-500/30 rounded-full">
                        <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></div>
                        <span className="text-xs text-green-400 font-medium">Live</span>
                      </div>
                    </div>
                    <p className="text-3xl font-bold text-white">{formatCurrency(todaySpend.spend)}</p>
                  </div>
                  <FiDollarSign className="w-8 h-8 text-green-400" />
                </div>
                <p className="text-xs text-white/50">{todaySpend.date}</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Today's Impressions</p>
                    <p className="text-3xl font-bold text-white">{formatNumber(todaySpend.impressions)}</p>
                  </div>
                  <FiEye className="w-8 h-8 text-blue-400" />
                </div>
                <p className="text-xs text-white/50">{todaySpend.date}</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Today's Link Clicks</p>
                    <p className="text-3xl font-bold text-white">{formatNumber(todaySpend.clicks)}</p>
                  </div>
                  <FiMousePointer className="w-8 h-8 text-purple-400" />
                </div>
                <p className="text-xs text-white/50">Users who clicked to external sites</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Today's Link CTR</p>
                    <p className="text-3xl font-bold text-white">{todaySpend.ctr.toFixed(2)}%</p>
                  </div>
                  <FiTrendingUp className="w-8 h-8 text-yellow-400" />
                </div>
                <p className="text-xs text-white/50">Link click-through rate</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Today's CPM</p>
                    <p className="text-3xl font-bold text-white">{formatCurrency(todaySpend.cpm)}</p>
                  </div>
                  <FiDollarSign className="w-8 h-8 text-orange-400" />
                </div>
                <p className="text-xs text-white/50">Cost per 1,000 impressions</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Today's Link CPC</p>
                    <p className="text-3xl font-bold text-white">{formatCurrency(todaySpend.cpc)}</p>
                  </div>
                  <FiDollarSign className="w-8 h-8 text-red-400" />
                </div>
                <p className="text-xs text-white/50">Cost per link click</p>
              </div>
            </div>
          </div>

          {/* Live Ads */}
          <div className="animate-fade-in-up mb-8" style={{ animationDelay: '0.3s' }}>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-bold text-white mb-2">Live Ads</h3>
                <p className="text-sm text-white/60">Currently active ads with performance metrics</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-white/60">Total Active</p>
                <p className="text-2xl font-bold text-white">{liveAds.length}</p>
              </div>
            </div>
            
            {liveAds.length === 0 ? (
              <div className="glass-card p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FiRefreshCw className="w-8 h-8 text-white animate-spin" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Loading Active Ads...</h3>
                <p className="text-white/60 mb-4">
                  Meta API is currently rate-limited. Your active ads data will load once the rate limit resets (usually within 15-30 minutes).
                </p>
                <div className="flex items-center justify-center gap-2 text-sm text-white/50">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                  <span>Using cached data where available</span>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {liveAds.slice(0, 12).map((ad) => (
                  <div key={ad.id} className="glass-card p-6 glass-card-hover">
                    {/* Ad Image/Thumbnail */}
                    <div className="mb-4">
                      {ad.creative?.thumbnail_url || ad.creative?.image_url ? (
                        <div className="relative w-full aspect-square rounded-lg overflow-hidden bg-gray-800 shadow-lg">
                          <img 
                            src={ad.creative?.thumbnail_url || ad.creative?.image_url} 
                            alt={ad.name}
                            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105 high-quality-image"
                            loading="lazy"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              e.currentTarget.nextElementSibling?.classList.remove('hidden');
                            }}
                          />
                          <div className="hidden w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-700 to-gray-800">
                            <div className="text-center">
                              <FiTarget className="w-8 h-8 text-white/50 mx-auto mb-2" />
                              <p className="text-xs text-white/50">No Image</p>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="w-full aspect-square rounded-lg bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center shadow-lg">
                          <div className="text-center">
                            <FiTarget className="w-8 h-8 text-white/50 mx-auto mb-2" />
                            <p className="text-xs text-white/50">No Image Available</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Ad Info */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h4 className="font-semibold text-white line-clamp-2 mb-1">
                          {ad.name}
                        </h4>
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: ad.status_color }}
                          ></div>
                          <span className="text-xs text-white/60 capitalize">
                            {ad.effective_status.toLowerCase().replace('_', ' ')}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-sm font-bold ${getPerformanceColor(ad.metrics.performance_score)}`}>
                          {ad.metrics.performance_score}/100
                        </div>
                        <div className="text-xs text-white/50">
                          {getPerformanceLabel(ad.metrics.performance_score)}
                        </div>
                      </div>
                    </div>

                    {/* Key Metrics */}
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <span className="text-white/50">Spend:</span>
                        <span className="text-white ml-1 font-semibold">{formatCurrency(ad.metrics.spend)}</span>
                      </div>
                      <div>
                        <span className="text-white/50">Impressions:</span>
                        <span className="text-white ml-1 font-semibold">{formatNumber(ad.metrics.impressions)}</span>
                      </div>
                      <div>
                        <span className="text-white/50">Clicks:</span>
                        <span className="text-white ml-1 font-semibold">{formatNumber(ad.metrics.clicks)}</span>
                      </div>
                      <div>
                        <span className="text-white/50">CTR:</span>
                        <span className="text-white ml-1 font-semibold">{ad.metrics.ctr.toFixed(2)}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Historical Performance (Last 30 Days) */}
          <div className="animate-fade-in-up mb-8" style={{ animationDelay: '0.4s' }}>
            <h3 className="text-lg font-bold text-white mb-4">Last 30 Days Performance</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Total Ads</p>
                    <p className="text-3xl font-bold text-white">{adsSummary.totalAds}</p>
                  </div>
                  <FiTarget className="w-8 h-8 text-white/30" />
                </div>
                <p className="text-xs text-white/50">Last 30 days</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Total Spend</p>
                    <p className="text-3xl font-bold text-white">{formatCurrency(adsSummary.totalSpend)}</p>
                  </div>
                  <FiDollarSign className="w-8 h-8 text-white/30" />
                </div>
                <p className="text-xs text-white/50">Last 30 days</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Total Impressions</p>
                    <p className="text-3xl font-bold text-white">{formatNumber(adsSummary.totalImpressions)}</p>
                  </div>
                  <FiEye className="w-8 h-8 text-white/30" />
                </div>
                <p className="text-xs text-white/50">Last 30 days</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Total Clicks</p>
                    <p className="text-3xl font-bold text-white">{formatNumber(adsSummary.totalClicks)}</p>
                  </div>
                  <FiMousePointer className="w-8 h-8 text-white/30" />
                </div>
                <p className="text-xs text-white/50">Last 30 days</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Average CTR</p>
                    <p className="text-3xl font-bold text-white">{adsSummary.averageCTR.toFixed(2)}%</p>
                  </div>
                  <FiTrendingUp className="w-8 h-8 text-white/30" />
                </div>
                <p className="text-xs text-white/50">Last 30 days average</p>
              </div>

              <div className="glass-card p-6 glass-card-hover">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-white/60">Average CPM</p>
                    <p className="text-3xl font-bold text-white">{formatCurrency(adsSummary.averageCPM)}</p>
                  </div>
                  <FiDollarSign className="w-8 h-8 text-white/30" />
                </div>
                <p className="text-xs text-white/50">Last 30 days average</p>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
            <div className="glass-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-green-500 to-blue-600 flex items-center justify-center">
                  <FiActivity className="w-3 h-3 text-white" />
                </div>
                <h2 className="text-lg font-bold text-white">Quick Actions</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <button className="p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-left">
                  <div className="flex items-center gap-3">
                    <FiTarget className="w-5 h-5 text-blue-400" />
                    <div>
                      <p className="font-medium text-white">View Live Ads</p>
                      <p className="text-xs text-white/60">See active campaigns</p>
                    </div>
                  </div>
                </button>
                
                <button className="p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-left">
                  <div className="flex items-center gap-3">
                    <FiTrendingUp className="w-5 h-5 text-green-400" />
                    <div>
                      <p className="font-medium text-white">Analyze Performance</p>
                      <p className="text-xs text-white/60">Get AI insights</p>
                    </div>
                  </div>
                </button>
                
                <button className="p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-left">
                  <div className="flex items-center gap-3">
                    <FiActivity className="w-5 h-5 text-purple-400" />
                    <div>
                      <p className="font-medium text-white">Creative Ideas</p>
                      <p className="text-xs text-white/60">AI recommendations</p>
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
